<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vYE8HelzyztJh502',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f4hpBFn5rMi8C6Rg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login.process',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.forgot.password',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/otp-send' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.send.otp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/resend-otp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.resend.otp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/verify-otp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.verify.otp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/check-otp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.validate.otp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reset.password',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/update-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.update.password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/profile/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.change.password',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/edit-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.edit.password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/management' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.management',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/datatable/user-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/management/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.management.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/management/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/management/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/datatable/role-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activity',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/datatable/activity-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activity.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/activity/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.activity.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.user.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/users-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.user.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/trusts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.trust.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/trusts-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.trust.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/donors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.donor.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/donors-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.donor.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/receipts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/receipt/modal-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.modal-data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/receipts-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dms/receipt/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.export',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/menu/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.menu.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/institute/select' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.set.active.institute',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/modules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.modules',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/modules/visibility' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.module.visibility.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/contents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.contents',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/contents/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/contents/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/content/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page/contents/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page/contents/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page/content/media/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.media.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page/content/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/landing-page/content/media/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.media.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/header' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/header/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/header/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/header/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/footer/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/footer/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/footer/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/modules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.modules',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/modules/visibility' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.module.visibility.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/contents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.contents',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/contents/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/contents/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/content/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/contents/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/content/manage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.manage',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/contents/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/content/media/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.media.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/content/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/landing-page/content/media/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.media.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/header' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/header/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/header/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/header/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/footer/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/footer/update-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.updateOrder',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/cms/main/footer/section/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.section.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home-theme' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home-theme',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/admin/(?|management/(?|edit/([^/]++)(*:44)|update/([^/]++)(*:66)|view/([^/]++)(*:86))|role/(?|edit/([^/]++)(*:115)|update/([^/]++)(*:138))|dms/(?|user/view/([^/]++)(*:172)|trust/view/([^/]++)(*:199)|donor/view/([^/]++)(*:226)|receipt/(?|view/([^/]++)(*:258)|pdf/([^/]++)(*:278)))|cms/(?|m(?|enu/list/institute/([^/]++)(*:326)|ain/(?|get\\-submenus/([^/]++)(*:363)|c(?|ontent/(?|edit/([^/]++)(*:398)|update/([^/]++)(*:421)|manage/([^/]++)(*:444))|heck\\-content/([^/]++)(*:475))|landing\\-page/content/(?|edit/([^/]++)(*:522)|update/([^/]++)(*:545))|header/(?|toggle\\-section\\-status/([^/]++)(*:596)|edit/([^/]++)(*:617)|update/([^/]++)(*:640))|footer/(?|toggle\\-section\\-status/([^/]++)(*:691)|edit/([^/]++)(*:712)|update/([^/]++)(*:735))))|get\\-submenus/([^/]++)(*:768)|c(?|heck\\-content/([^/]++)(*:802)|ontent/(?|manage/([^/]++)(*:835)|edit/([^/]++)(*:856)|update/([^/]++)(*:879)))|landing\\-page/content/(?|manage/([^/]++)(*:929)|edit/([^/]++)(*:950)|update/([^/]++)(*:973))|header/(?|toggle\\-section\\-status/([^/]++)(*:1024)|edit/([^/]++)(*:1046)|update/([^/]++)(*:1070))|footer/(?|toggle\\-section\\-status/([^/]++)(*:1122)|edit/([^/]++)(*:1144)|update/([^/]++)(*:1168))))|/storage/(.*)(*:1193))/?$}sDu',
    ),
    3 => 
    array (
      44 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      66 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      86 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.user.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      138 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.user.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.trust.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      226 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.donor.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dms.receipt.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.institute.menu.list',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      363 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.submenu',
          ),
          1 => 
          array (
            0 => 'parentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      398 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.edit',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      421 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.update',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      444 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.manage',
          ),
          1 => 
          array (
            0 => 'menuId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      475 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.content.check',
          ),
          1 => 
          array (
            0 => 'menuId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.edit',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.landing.page.content.update',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.toggle-section-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      617 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.edit',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.header.update',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.toggle-section-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.edit',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      735 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.main.footer.update',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.submenu',
          ),
          1 => 
          array (
            0 => 'parentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.check',
          ),
          1 => 
          array (
            0 => 'menuId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      835 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.manage',
          ),
          1 => 
          array (
            0 => 'menuId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      856 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.edit',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.content.update',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      929 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.manage',
          ),
          1 => 
          array (
            0 => 'instituteId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      950 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.edit',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.landing.page.content.update',
          ),
          1 => 
          array (
            0 => 'contentId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1024 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.toggle-section-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1046 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.edit',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.header.update',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1122 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.toggle-section-status',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1144 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.edit',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1168 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.cms.footer.update',
          ),
          1 => 
          array (
            0 => 'sectionId',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::vYE8HelzyztJh502' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:831:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'D:\\\\Project\\\\Shineinfosoft-CMS\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000004e50000000000000000";}}',
        'as' => 'generated::vYE8HelzyztJh502',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f4hpBFn5rMi8C6Rg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::f4hpBFn5rMi8C6Rg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/home',
        'status' => 302,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@showLoginForm',
        'as' => 'admin.login',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login.process' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@login',
        'as' => 'admin.login.process',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\LoginController@logout',
        'as' => 'admin.logout',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.forgot.password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@forgotPassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@forgotPassword',
        'as' => 'admin.forgot.password',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.send.otp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/otp-send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@sendOTP',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@sendOTP',
        'as' => 'admin.send.otp',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.resend.otp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/resend-otp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@reSendOTP',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@reSendOTP',
        'as' => 'admin.resend.otp',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.verify.otp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/verify-otp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@verifyOtp',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@verifyOtp',
        'as' => 'admin.verify.otp',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.validate.otp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/check-otp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@checkOtpValidation',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@checkOtpValidation',
        'as' => 'admin.validate.otp',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reset.password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@resetPassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@resetPassword',
        'as' => 'admin.reset.password',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.update.password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/update-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\ForgotPasswordController@updatePassword',
        'as' => 'admin.update.password',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'as' => 'admin.dashboard',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@index',
        'as' => 'admin.profile',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/profile/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@update',
        'as' => 'admin.profile.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.change.password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@changePassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@changePassword',
        'as' => 'admin.change.password',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.edit.password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/edit-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfileController@editPassword',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfileController@editPassword',
        'as' => 'admin.edit.password',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.management' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/management',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@index',
        'as' => 'admin.management',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/datatable/user-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@getUserList',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@getUserList',
        'as' => 'admin.user.data',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.management.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/management/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@addAdmin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@addAdmin',
        'as' => 'admin.management.add',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/management/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@create',
        'as' => 'admin.user.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/management/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@editAdmin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@editAdmin',
        'as' => 'admin.user.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/management/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@update',
        'as' => 'admin.user.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/management/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@viewAdmin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@viewAdmin',
        'as' => 'admin.user.view',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.user.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/management/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminManagementController@destroy',
        'as' => 'admin.user.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@index',
        'as' => 'admin.role',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/datatable/role-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@getRoleList',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@getRoleList',
        'as' => 'admin.role.data',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/role/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@addRole',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@addRole',
        'as' => 'admin.role.add',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@create',
        'as' => 'admin.role.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/role/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@editRole',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@editRole',
        'as' => 'admin.role.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/role/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@update',
        'as' => 'admin.role.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/role/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleManagementController@destroy',
        'as' => 'admin.role.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activity' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@index',
        'as' => 'admin.activity',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activity.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/datatable/activity-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@getActivityList',
        'controller' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@getActivityList',
        'as' => 'admin.activity.data',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.activity.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/activity/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ActivityLogController@destroy',
        'as' => 'admin.activity.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\DashboardController@index',
        'as' => 'admin.dms.dashboard',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.user.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@userList',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@userList',
        'as' => 'admin.dms.user.list',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.user.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/users-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@getUserData',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@getUserData',
        'as' => 'admin.dms.user.data',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.user.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/user/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@viewUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\UserController@viewUser',
        'as' => 'admin.dms.user.view',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.trust.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/trusts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@trustList',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@trustList',
        'as' => 'admin.dms.trust.list',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.trust.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/trusts-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@getTrustData',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@getTrustData',
        'as' => 'admin.dms.trust.data',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.trust.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/trust/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@viewTrust',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\TrustController@viewTrust',
        'as' => 'admin.dms.trust.view',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.donor.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/donors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@donorList',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@donorList',
        'as' => 'admin.dms.donor.list',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.donor.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/donors-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@getDonorData',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@getDonorData',
        'as' => 'admin.dms.donor.data',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.donor.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/donor/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@viewDonor',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\DonorController@viewDonor',
        'as' => 'admin.dms.donor.view',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/receipts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@receiptList',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@receiptList',
        'as' => 'admin.dms.receipt.list',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.modal-data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/receipt/modal-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@modalData',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@modalData',
        'as' => 'admin.dms.receipt.modal-data',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/receipts-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@getReceiptData',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@getReceiptData',
        'as' => 'admin.dms.receipt.data',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/receipt/view/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@viewReceipt',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@viewReceipt',
        'as' => 'admin.dms.receipt.view',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.export' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/dms/receipt/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@export',
        'as' => 'admin.dms.receipt.export',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dms.receipt.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dms/receipt/pdf/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@exportPdf',
        'controller' => 'App\\Http\\Controllers\\Admin\\DMS\\ReceiptController@exportPdf',
        'as' => 'admin.dms.receipt.pdf',
        'namespace' => NULL,
        'prefix' => 'admin/dms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.menu.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/menu/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@storeOrUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@storeOrUpdate',
        'as' => 'admin.cms.menu.create',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.institute.menu.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/menu/list/institute/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@listByInstitute',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@listByInstitute',
        'as' => 'admin.cms.institute.menu.list',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.set.active.institute' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/institute/select',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\InstituteController@setActiveInstitute',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\InstituteController@setActiveInstitute',
        'as' => 'admin.cms.set.active.institute',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.modules' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/modules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@modulesView',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@modulesView',
        'as' => 'admin.cms.modules',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.module.visibility.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/modules/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@updateMenuVisibility',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@updateMenuVisibility',
        'as' => 'admin.cms.module.visibility.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.submenu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/get-submenus/{parentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@getSubmenus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\MenuController@getSubmenus',
        'as' => 'admin.cms.submenu',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.contents' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/contents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentsView',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentsView',
        'as' => 'admin.cms.contents',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/contents/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentsCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentsCreate',
        'as' => 'admin.cms.content.submit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.check' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/check-content/{menuId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@checkContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@checkContent',
        'as' => 'admin.cms.content.check',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/content/manage/{menuId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@manageContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@manageContent',
        'as' => 'admin.cms.content.manage',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/content/edit/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@editContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@editContent',
        'as' => 'admin.cms.content.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/content/update/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@contentUpdate',
        'as' => 'admin.cms.content.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/contents/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@updateOrder',
        'as' => 'admin.cms.content.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.content.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/content/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\ContentController@destroySection',
        'as' => 'admin.cms.content.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/landing-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@index',
        'as' => 'admin.cms.landing.page',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/landing-page/contents/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@contentsCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@contentsCreate',
        'as' => 'admin.cms.landing.page.content.submit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/landing-page/content/manage/{instituteId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@manageContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@manageContent',
        'as' => 'admin.cms.landing.page.content.manage',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/landing-page/content/edit/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@editContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@editContent',
        'as' => 'admin.cms.landing.page.content.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/landing-page/content/update/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@contentUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@contentUpdate',
        'as' => 'admin.cms.landing.page.content.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/landing-page/contents/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@updateOrder',
        'as' => 'admin.cms.landing.page.content.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.media.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/landing-page/content/media/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@updateMediaOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@updateMediaOrder',
        'as' => 'admin.cms.landing.page.content.media.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/landing-page/content/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@destroySection',
        'as' => 'admin.cms.landing.page.content.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.landing.page.content.media.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/landing-page/content/media/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@destroyMediaSection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\LandingPageController@destroyMediaSection',
        'as' => 'admin.cms.landing.page.content.media.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/header',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@index',
        'as' => 'admin.cms.header',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/header/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@headerStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@headerStore',
        'as' => 'admin.cms.header.store',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.toggle-section-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/header/toggle-section-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@toggleSectionStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@toggleSectionStatus',
        'as' => 'admin.cms.header.toggle-section-status',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/header/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@updateOrder',
        'as' => 'admin.cms.header.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/header/edit/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@edit',
        'as' => 'admin.cms.header.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/header/update/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@updateHeader',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@updateHeader',
        'as' => 'admin.cms.header.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.header.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/header/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\HeaderController@destroySection',
        'as' => 'admin.cms.header.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@index',
        'as' => 'admin.cms.footer',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/footer/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@footerStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@footerStore',
        'as' => 'admin.cms.footer.store',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.toggle-section-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/footer/toggle-section-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@toggleSectionStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@toggleSectionStatus',
        'as' => 'admin.cms.footer.toggle-section-status',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/footer/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@updateOrder',
        'as' => 'admin.cms.footer.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/footer/edit/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@edit',
        'as' => 'admin.cms.footer.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/footer/update/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@updateFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@updateFooter',
        'as' => 'admin.cms.footer.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.footer.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/footer/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\FooterController@destroySection',
        'as' => 'admin.cms.footer.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.modules' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/modules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@modulesView',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@modulesView',
        'as' => 'admin.cms.main.modules',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.module.visibility.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/modules/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@updateMenuVisibility',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@updateMenuVisibility',
        'as' => 'admin.cms.main.module.visibility.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.submenu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/get-submenus/{parentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@getSubmenus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\MenuController@getSubmenus',
        'as' => 'admin.cms.main.submenu',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.contents' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/contents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentsView',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentsView',
        'as' => 'admin.cms.main.contents',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/contents/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentsCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentsCreate',
        'as' => 'admin.cms.main.content.submit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/content/edit/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@editContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@editContent',
        'as' => 'admin.cms.main.content.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/content/update/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@contentUpdate',
        'as' => 'admin.cms.main.content.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.check' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/check-content/{menuId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@checkContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@checkContent',
        'as' => 'admin.cms.main.content.check',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/content/manage/{menuId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@manageContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@manageContent',
        'as' => 'admin.cms.main.content.manage',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/contents/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@updateOrder',
        'as' => 'admin.cms.main.content.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.content.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/main/content/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\ContentController@destroySection',
        'as' => 'admin.cms.main.content.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/landing-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@index',
        'as' => 'admin.cms.main.landing.page',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/landing-page/contents/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@contentsCreate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@contentsCreate',
        'as' => 'admin.cms.main.landing.page.content.submit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.manage' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/landing-page/content/manage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@manageContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@manageContent',
        'as' => 'admin.cms.main.landing.page.content.manage',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/landing-page/content/edit/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@editContent',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@editContent',
        'as' => 'admin.cms.main.landing.page.content.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/landing-page/content/update/{contentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@contentUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@contentUpdate',
        'as' => 'admin.cms.main.landing.page.content.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/landing-page/contents/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@updateOrder',
        'as' => 'admin.cms.main.landing.page.content.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.media.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/landing-page/content/media/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@updateMediaOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@updateMediaOrder',
        'as' => 'admin.cms.main.landing.page.content.media.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/main/landing-page/content/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@destroySection',
        'as' => 'admin.cms.main.landing.page.content.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.landing.page.content.media.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/main/landing-page/content/media/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@destroyMediaSection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\LandingPageController@destroyMediaSection',
        'as' => 'admin.cms.main.landing.page.content.media.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/header',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@index',
        'as' => 'admin.cms.main.header',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/header/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@headerStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@headerStore',
        'as' => 'admin.cms.main.header.store',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.toggle-section-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/header/toggle-section-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@toggleSectionStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@toggleSectionStatus',
        'as' => 'admin.cms.main.header.toggle-section-status',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/header/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@updateOrder',
        'as' => 'admin.cms.main.header.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/header/edit/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@edit',
        'as' => 'admin.cms.main.header.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/header/update/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@updateHeader',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@updateHeader',
        'as' => 'admin.cms.main.header.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.header.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/main/header/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\HeaderController@destroySection',
        'as' => 'admin.cms.main.header.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@index',
        'as' => 'admin.cms.main.footer',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/footer/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@footerStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@footerStore',
        'as' => 'admin.cms.main.footer.store',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.toggle-section-status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/footer/toggle-section-status/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@toggleSectionStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@toggleSectionStatus',
        'as' => 'admin.cms.main.footer.toggle-section-status',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.updateOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/footer/update-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@updateOrder',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@updateOrder',
        'as' => 'admin.cms.main.footer.updateOrder',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/cms/main/footer/edit/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@edit',
        'as' => 'admin.cms.main.footer.edit',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/cms/main/footer/update/{sectionId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@updateFooter',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@updateFooter',
        'as' => 'admin.cms.main.footer.update',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.cms.main.footer.section.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/cms/main/footer/section/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'custom.auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@destroySection',
        'controller' => 'App\\Http\\Controllers\\Admin\\CMS\\Main_web\\FooterController@destroySection',
        'as' => 'admin.cms.main.footer.section.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/cms/main',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home-theme' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home-theme',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@homeTheme',
        'controller' => 'App\\Http\\Controllers\\HomeController@homeTheme',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home-theme',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@about',
        'controller' => 'App\\Http\\Controllers\\HomeController@about',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'about',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:48:"D:\\Project\\Shineinfosoft-CMS\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000004ea0000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
