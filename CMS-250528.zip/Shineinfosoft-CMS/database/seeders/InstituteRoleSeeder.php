<?php

namespace Database\Seeders;

use App\Models\Institute;
use App\Models\Menu;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class InstituteRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */

    //  php artisan db:seed --class=InstituteRoleSeeder

    public function run(): void
    {
        $instituteMenus = [
            'Shine Infosoft Website' => [
                [
                    'title' => 'Administration',
                    'slug' => 'administration',
                    'children' => [
                        [
                            'title' => 'Sandipani Vidya Sankul Saputara',
                            'slug' => 'administration/sandipani_vidya_sankul_saputara',
                        ],
                        [
                            'title' => "Trustee's Desk",
                            'slug' => 'administration/trustees_desk',
                        ],
                        [
                            'title' => "Student's Strength",
                            'slug' => 'administration/students_strength',
                        ],
                        [
                            'title' => "Teachers & Staff",
                            'slug' => 'administration/teachers_staff',
                        ],
                        [
                            'title' => "Policies",
                            'slug' => 'administration/policies',
                        ],
                        [
                            'title' => "Milestones",
                            'slug' => 'administration/milestones',
                        ],
                        [
                            'title' => "Future Plan",
                            'slug' => 'administration/future_plan',
                        ],
                        [
                            'title' => "Contact Us",
                            'slug' => 'administration/contact_us',
                        ],
                    ]
                ],
                [
                    'title' => 'Academics',
                    'slug' => 'academics',
                    'children' => [
                        [
                            'title' => 'Syllabus & Curriculum',
                            'slug' => 'academics/syllabus_curriculum',
                        ],
                        [
                            'title' => 'Evalution System',
                            'slug' => 'academics/evalution_system',
                        ],
                        [
                            'title' => 'Home Learning Lesson',
                            'slug' => 'academics/home_learning_lesson',
                        ],
                        [
                            'title' => 'Pre-School, Pre-Primary, 1 & 2',
                            'slug' => 'academics/pre_school_primary',
                        ],
                    ]
                ],
                [
                    'title' => 'Infra & Facilities',
                    'slug' => 'infra_facilities',
                    'children' => [
                        [
                            'title' => 'Canteen Facilities',
                            'slug' => 'infra_facilities/canteen',
                        ],
                        [
                            'title' => 'Infrastructural Facilities',
                            'slug' => 'infra_facilities/infrastructural',
                        ],
                        [
                            'title' => 'IT Infrastructure',
                            'slug' => 'infra_facilities/it_infrastructure',
                        ],
                        [
                            'title' => 'Medical Facilities',
                            'slug' => 'infra_facilities/medical',
                        ],
                        [
                            'title' => 'FAQs',
                            'slug' => 'infra_facilities/faqs',
                        ],
                        [
                            'title' => 'Science Lab',
                            'slug' => 'infra_facilities/science_lab',
                        ],
                        [
                            'title' => 'Transport Facilities',
                            'slug' => 'infra_facilities/transport',
                        ],
                    ]
                ],
                [
                    'title' => 'Admission',
                    'slug' => 'admission',
                    'children' => [
                        [
                            'title' => 'Online Admission',
                            'slug' => 'admission/online_admission',
                        ],
                        [
                            'title' => 'Admission Inquiry',
                            'slug' => 'admission/inquiry',
                        ],
                        [
                            'title' => 'Document List',
                            'slug' => 'admission/document_list',
                        ],
                        [
                            'title' => 'FAQs',
                            'slug' => 'admission/faqs',
                        ],
                    ]
                ],
                [
                    'title' => "Student's Corner",
                    'slug' => 'student_corner',
                    'children' => [
                        [
                            'title' => 'Celebration',
                            'slug' => 'student_corner/celebration',
                        ],
                        [
                            'title' => 'Notice Board',
                            'slug' => 'student_corner/notice_board',
                        ],
                        [
                            'title' => 'Connect to Teachers',
                            'slug' => 'student_corner/connect_to_teachers',
                        ],
                        [
                            'title' => 'School Calendar',
                            'slug' => 'student_corner/school_calendar',
                        ],
                        [
                            'title' => 'Home Work',
                            'slug' => 'student_corner/home_work',
                        ],
                    ]
                ],
                [
                    'title' => "Parent's Corner",
                    'slug' => 'parent_corner',
                    'children' => [
                        [
                            'title' => 'Admission Pre-School',
                            'slug' => 'parent_corner/admission_pre_school',
                        ],
                        [
                            'title' => 'Admission Open for Class KG to XII',
                            'slug' => 'parent_corner/admission_open',
                        ],
                        [
                            'title' => 'Bus Route List',
                            'slug' => 'parent_corner/bus_route_list',
                        ],
                        [
                            'title' => 'CBSE Affiliation Report',
                            'slug' => 'parent_corner/affiliation_report',
                        ],
                        [
                            'title' => 'Parents Meet',
                            'slug' => 'parent_corner/parents_meet',
                        ],
                        [
                            'title' => 'Fee Structure/ Fee Payment Online',
                            'slug' => 'parent_corner/online_fee_structure_payment',
                        ],
                        [
                            'title' => 'Withdrawal',
                            'slug' => 'parent_corner/withdrawal',
                        ],
                        [
                            'title' => 'School Calendar',
                            'slug' => 'parent_corner/school_calendar',
                        ],
                    ]
                ],
            ],
            // 'Gurukul Institute' => [
            //     [
            //         'title' => 'About Us',
            //         'slug' => 'about-us',
            //         'children' => [
            //             [
            //                 'title' => 'Mission',
            //                 'slug' => 'about-us/mission',
            //             ],
            //             [
            //                 'title' => 'Vision',
            //                 'slug' => 'about-us/vision',
            //             ],
            //         ]
            //     ],
            //     [
            //         'title' => 'Students',
            //         'slug' => 'student',
            //     ]
            // ],
        ];

        foreach ($instituteMenus as $instituteName => $menus) {
            $institute = Institute::create(['name' => $instituteName]);
            $this->createMenus($menus, $institute->id);
        }
    }

    private function createMenus(array $menus, int $instituteId, int $parentId = null): void
    {
        foreach ($menus as $menuData) {
            $children = $menuData['children'] ?? [];
            unset($menuData['children']);

            $menu = Menu::create([
                'institute_id' => $instituteId,
                'parent_id'    => $parentId,
                'title'        => $menuData['title'],
                'slug'         => $menuData['slug'],
            ]);

            if (!empty($children)) {
                $this->createMenus($children, $instituteId, $menu->id);
            }
        }
    }
}
