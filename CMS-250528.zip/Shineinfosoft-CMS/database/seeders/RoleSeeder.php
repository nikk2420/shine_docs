<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         // Create Super Admin Role
         $role = Role::create([
            'name' => 'Super Admin',
            'description' => 'Full access to the system',
            'is_active' => true,
        ]);

        // Define default modules
        $modules = config('modules.modules');

        // Give full permissions on all modules
        foreach ($modules as $module) {
            Permission::create([
                'module' => $module,
                'can_view' => true,
                'can_add' => true,
                'can_update' => true,
                'can_delete' => true,
                'role_id' => $role->id,
            ]);
        }
    }
}
