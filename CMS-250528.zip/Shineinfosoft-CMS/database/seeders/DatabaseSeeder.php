<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // Create Super Admin role
        $this->call([
            RoleSeeder::class,
        ]);
        
        $role = Role::firstOrCreate([
            'name' => 'Super Admin',
        ], [
            'description' => 'Full access to the system',
            'is_active' => true,
        ]);

        // Create Super Admin role
        $users = User::factory()->createMany([
            [
                'name' => 'Jitesh Joshi',
                'email' => 'joshijitesh4488@gmail.com',
                // 'mobile_number' => 9638380495,
                'role_id' => $role->id,
                'password' => bcrypt('ShineCMS@123'),
            ],
            [
                'name' => 'Hiren Prajapati',
                'email' => 'ha1@yopmail.com',
                // 'mobile_number' => 7043913569,
                'role_id' => $role->id,
                'password' => bcrypt('Admin@123'),
            ],
            [
                'name' => 'Test Admin',
                'email' => 'test_admin@yopmail.com',
                'role_id' => $role->id,
                'password' => bcrypt('@Shine123'),
            ],
        ]);

        $this->call([
            InstituteRoleSeeder::class,
        ]);
        
    }
}
