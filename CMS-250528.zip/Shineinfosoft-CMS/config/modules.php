<?php

return [
    'modules' => [
        'Dashboard',
        'Admins',
        'Roles',
        'Activity',
        'CMS Admin',
    ],
];
