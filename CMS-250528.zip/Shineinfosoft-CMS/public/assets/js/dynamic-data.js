/* Banner - Dynamic Generate Relative Code Start */
var bannerData = [
  { id: 1, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 2, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 3, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 4, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 5, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 6, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 7, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 8, imageURL: "assets/images/png/banner/banner_01.png" },
  { id: 9, imageURL: "assets/images/png/banner/banner_01.png" },
];
function bannerGenerateCard(bannerData) {
  var card = `
    <div class="item">
      <div class="owl-carousel-content-box overlay-box">
        <img src="${bannerData.imageURL}" alt="Banner Image" />
      </div>
    </div>
  `;
  return card;
}
function bannerCard(bannerData) {
  var container = document.querySelector('.owl-slider-container.owl-banner-image-carousel .owl-carousel');
  container.innerHTML = ''; // Clear existing content
  bannerData.forEach(bannerItem => {
    var cardHTML = bannerGenerateCard(bannerItem);
    container.insertAdjacentHTML('beforeend', cardHTML);
  });
}
/* Banner - Dynamic Generate Relative Code End */

/* Sandipani group of schools - Card Dynamic Generate Relative Code Start */
var sandipaniGroupOfSchoolsData = [
  {
    id: 1,
    imageURL: "assets/images/png/sandipani-group-of-schools/sandipani_group_of_schools_01.png",
    title: "Sandipani Gurukul",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt iure voluptatem maiores sit aut adipisci molestias. Fuga in, labore autem eligendi et inventore expedita minima ex, totam mollitia eos animi!",
  },
  {
    id: 2,
    imageURL: "assets/images/png/sandipani-group-of-schools/sandipani_group_of_schools_02.png",
    title: "Sandipani Rishikul",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt iure voluptatem maiores sit aut adipisci molestias. Fuga in, labore autem eligendi et inventore expedita minima ex, totam mollitia eos animi!",
  },
  {
    id: 3,
    imageURL: "assets/images/png/sandipani-group-of-schools/sandipani_group_of_schools_03.png",
    title: "Sandipani Manidweep",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt iure voluptatem maiores sit aut adipisci molestias. Fuga in, labore autem eligendi et inventore expedita minima ex, totam mollitia eos animi!",
  },
  {
    id: 4,
    imageURL: "assets/images/png/sandipani-group-of-schools/sandipani_group_of_schools_04.png",
    title: "Devka Vidyapeeth (DVP)",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt iure voluptatem maiores sit aut adipisci molestias. Fuga in, labore autem eligendi et inventore expedita minima ex, totam mollitia eos animi!",
  },
  {
    id: 5,
    imageURL: "assets/images/png/sandipani-group-of-schools/sandipani_group_of_schools_05.png",
    title: "Sandipani Vidya Sankul Saputara (SVS)",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt iure voluptatem maiores sit aut adipisci molestias. Fuga in, labore autem eligendi et inventore expedita minima ex, totam mollitia eos animi!",
  },
];
function sandipaniGroupOfSchoolsGenerateCard(sandipaniGroupOfSchoolsData) {
  var card = `
    <div class="item">
      <div class="image-slide-up-content-box">
        <div class="image-content-box">
          <img src="${sandipaniGroupOfSchoolsData.imageURL}" alt="Sandipani Group of Schools" />
        </div>
        <div class="relative-content-box">
          <div class="clamp-text">
            <h4 class="poppins-bold-20">${sandipaniGroupOfSchoolsData.title}</h4>
          </div>
          <div class="slide-to-up">
            <div class="clamp-text">
              <p>${sandipaniGroupOfSchoolsData.description}</p>
            </div>
            <a href="#" class="arrow-link"><span>Visit Now</span>&nbsp;<i class="fa-solid fa-arrow-right-long"></i></a>
          </div>
        </div>
      </div>
    </div>
  `;
  return card;
}
function sandipaniGroupOfSchoolsCard(sandipaniGroupOfSchoolsData) {
  var container = document.querySelector('.owl-slider-container.owl-card-detail-carousel .owl-carousel');
  container.innerHTML = ''; // Clear existing content
  sandipaniGroupOfSchoolsData.forEach(sandipaniGroupOfSchoolsItem => {
    var cardHTML = sandipaniGroupOfSchoolsGenerateCard(sandipaniGroupOfSchoolsItem);
    container.insertAdjacentHTML('beforeend', cardHTML);
  });
}
/* Sandipani group of schools - Card Dynamic Generate Relative Code End */

/* Seva Yagya - Card Dynamic Generate Relative Code Start */
var sevaYagyaData = [
  {
    id: 1,
    imageURL: "assets/images/png/seva-yagya/seva_yagya_01.png",
    title: "Come for education, leave to serve society",
  },
  {
    id: 2,
    imageURL: "assets/images/png/seva-yagya/seva_yagya_02.png",
    title: "Cow is the mother of the universe.",
  },
  {
    id: 3,
    imageURL: "assets/images/png/seva-yagya/seva_yagya_03.png",
    title: "Which is supported by contributions and support from others",
  },
];
function sevaYagyaGenerateCard(sevaYagyaData) {
  var card = `
    <div class="item">
      <div class="card-container event-card">
        <div class="card">
          <div class="card-content-box">
            <div class="card-header">
              <img src="${sevaYagyaData.imageURL}" alt="Upcoming Events" />
            </div>
            <div class="card-body">
              <div class="content-box poppins-18">
                <h3 class="poppins-extra-bold-26 text-primary-3">${sevaYagyaData.title}</h3>
              </div>
            </div>
            <div class="card-footer">
              <a href="#" class="arrow-link"><span>More Details</span>&nbsp;<i class="fa-solid fa-arrow-right-long"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  return card;
}
function sevaYagyaCard(sevaYagyaData) {
  var container = document.querySelector('.owl-slider-container.owl-seva-yagya-carousel .owl-carousel');
  container.innerHTML = ''; // Clear existing content
  sevaYagyaData.forEach(sevaYagyaItem => {
    var cardHTML = sevaYagyaGenerateCard(sevaYagyaItem);
    container.insertAdjacentHTML('beforeend', cardHTML);
  });
}
/* Seva Yagya - Card Dynamic Generate Relative Code End */

/* Upcoming Events - Card Dynamic Generate Relative Code Start */
var upComingEventsData = [
  {
    id: 1,
    imageURL: "assets/images/png/event/event_01.png",
    title: "Shrimad Bhagavat Katha- Dholera",
    description: "March 16 At 9:30AM To March 22 At 1:30PM",
  },
  {
    id: 2,
    imageURL: "assets/images/png/event/event_02.png",
    title: "Shree Ram Katha - Delhi",
    description: "March 29 At 4:00AM To April 6 At 7:30PM",
  },
  {
    id: 3,
    imageURL: "assets/images/png/event/event_03.png",
    title: "Chaitra Navratri At ShriHari Mandir",
    description: "March 30 At 8:00AM To April 6 At 8:00PM",
  },
];
function upcomingEventGenerateCard(upComingEventsData) {
  var card = `
    <div class="item">
      <div class="card-container event-card">
        <div class="card">
          <div class="card-content-box">
            <div class="card-header">
              <img src="${upComingEventsData.imageURL}" alt="Upcoming Events" />
            </div>
            <div class="card-body">
              <div class="content-box poppins-18">
                <h3 class="poppins-extra-bold-26 text-underline-primary-3">${upComingEventsData.title}</h3>
                <p>${upComingEventsData.description}</p>
              </div>
            </div>
            <div class="card-footer">
              <a href="#" class="arrow-link"><span>More Details</span>&nbsp;<i class="fa-solid fa-arrow-right-long"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
  return card;
}
function upcomingEventCard(upComingEventsData) {
  var container = document.querySelector('.owl-slider-container.owl-upcoming-events-carousel .owl-carousel');
  container.innerHTML = ''; // Clear existing content
  upComingEventsData.forEach(upComingEventItem => {
    var cardHTML = upcomingEventGenerateCard(upComingEventItem);
    container.insertAdjacentHTML('beforeend', cardHTML);
  });
}
/* Upcoming Events - Card Dynamic Generate Relative Code End */

/* Divine Wisdom For Everyday Life - Card Dynamic Generate Relative Code Start */
var divineWisdomData = [
  {
    id: 1,
    sanskritShlok: ["जीवनसे श्रीकृष्णको जुदा मत समजो |", "जो श्रीकृष्णसे प्रेम करेगा वह जिंदगीसे प्रेम करेगा |"],
    hindi: ["जीवनसे श्रीकृष्णको जुदा मत समजो |", "जो श्रीकृष्णसे प्रेम करेगा वह जिंदगीसे प्रेम करेगा |"],
    englishDescription: ["Do not consider Lord Krishna to be separate from life. One who loves Lord Krishna will love life."]
  }
];
function divineWisdomGenerateCard(divineWisdomData) {
  var card = `
    <li>
      <div class="cover-flow-content-box">
        <div class="shlok-content-box">
          <p>जीवनसे श्रीकृष्णको जुदा मत समजो |</p>
          <p>जो श्रीकृष्णसे प्रेम करेगा वह जिंदगीसे प्रेम करेगा ||</p>
        </div>
        <div class="hindi-content-box"></div>
        <div class="english-content-box"></div>
      </div>
    </li>
  `;
  return card;
}
function divineWisdomCard(divineWisdomData) {
  var container = document.querySelector('.divine-wisdom-coverflow-slider .flip-items');
  container.innerHTML = ''; // Clear existing content
  divineWisdomData.forEach(divineWisdomItem => {
    var cardHTML = divineWisdomGenerateCard(divineWisdomItem);
    container.insertAdjacentHTML('beforeend', cardHTML);
  });
}
/* Divine Wisdom For Everyday Life - Card Dynamic Generate Relative Code End */

/* Condition Based - Create Object - Loop Data - Relative Code Start */
const dynamicSectionList = [
  {
    selector: ".owl-slider-container.owl-banner-image-carousel .owl-carousel",
    callback: () => bannerCard(bannerData),
  },
  {
    selector: ".owl-slider-container.owl-seva-yagya-carousel .owl-carousel",
    callback: () => sevaYagyaCard(sevaYagyaData),
  },
  {
    selector: ".owl-slider-container.owl-card-detail-carousel .owl-carousel",
    callback: () => sandipaniGroupOfSchoolsCard(sandipaniGroupOfSchoolsData),
  },
];
function conditionBasedDynamicFunctionCall() {
  dynamicSectionList.forEach(section => {
    if ($(section.selector).length) {
      section.callback();
    }
  });
}
/* Condition Based - Create Object - Loop Data - Relative Code End */

$(document).ready(function() {
  conditionBasedDynamicFunctionCall();
  /* upcomingEventCard(upComingEventsData); */
  /* divineWisdomCard(divineWisdomData); */
});