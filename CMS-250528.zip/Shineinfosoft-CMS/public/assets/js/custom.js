/* Loader Dynamic Create - Relative Code Start */

/* <div class="loader-container fixed-loader">
  <div class="loader-content-box">
    <div class="loader"></div>
  </div>
</div> */
// const loaderContainer = document.createElement("div");
// loaderContainer.className = "loader-container";
// const loaderContent = document.createElement("div");
// loaderContent.className = "loader-content-box";
// const loader = document.createElement("div");
// loader.className = "loader";
// loaderContent.appendChild(loader);
// loaderContainer.appendChild(loaderContent);
// document.body.appendChild(loaderContainer);

// window.addEventListener("load", function () {
//   loaderContainer.className = "loader-container fixed-loader";
//   setTimeout(() => {
//     loaderContainer.style.display = "none";
//   }, 0);
// });
/* Loader Dynamic Create - Relative Code End */

/* Scroll Down - Class Add into Navbar - Relative Code Start */
$(".header-section").removeClass("fixed-top");
$(window).scroll(function () {
  var scroll = $(window).scrollTop();
  if (scroll > 140) {
    $(".header-section").addClass("fixed-top");
  } else {
    $(".header-section").removeClass("fixed-top");
  }
});
/* Scroll Down - Class Add into Navbar - Relative Code End */

/* Header - Navbar Menu - Dropdown with Submenu Smoothly open & left and right not cut menu - Relative Code Start */
function checkSubPos() {
  document.querySelectorAll('.dropdown-menu').forEach(m => {
    const isRoot = m.parentElement.closest('ul').classList.contains('navbar-nav');
    m.classList.remove('left-align', 'root-left');
    const d = m.style.display, v = m.style.visibility;
    m.style.visibility = 'hidden'; m.style.display = 'block';
    if (m.getBoundingClientRect().right > window.innerWidth)
      m.classList.add(isRoot ? 'root-left' : 'left-align');
      m.style.display = d; m.style.visibility = v;
  });
}
document.querySelectorAll('.dropdown-menu').forEach(m => {
  const p = m.parentElement;
  p.addEventListener('mouseenter', () => {
  checkSubPos();
  requestAnimationFrame(() => {
      m.classList.remove('show-animated');
      void m.offsetWidth;
      m.classList.add('show-animated');
  });
  });
  p.addEventListener('mouseleave', () => m.classList.remove('show-animated'));
});
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".dropdown-item, .nav-link").forEach(function (el) {
    const href = el.getAttribute("href");
    if (!href || href === "#") {
      const button = document.createElement("button");
      [...el.attributes].forEach(attr => {
        if (attr.name !== "href") {
          button.setAttribute(attr.name, attr.value);
        }
      });
      button.innerHTML = el.innerHTML;
      el.parentNode.replaceChild(button, el);
    }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const currentPath = window.location.pathname;
  document.querySelectorAll(".dropdown-item[href]").forEach(link => {
    const linkPath = new URL(link.href).pathname;
    if (linkPath === currentPath) {
      link.classList.add("active");
      let parent = link.closest("li");
      while (parent) {
        const parentBtn = parent.querySelector("button.nav-link, button.dropdown-item");
        if (parentBtn) {
          parentBtn.classList.add("active");
        }

        const ul = parent.closest("ul");
        parent = ul.closest("li");
      }
    }
  });
});

window.addEventListener('resize', checkSubPos);
/* Header - Navbar Menu - Dropdown with Submenu Smoothly open & left and right not cut menu - Relative Code End */

$(document).ready(function () {
  /* Header Search Icon Click Relative Code Start */
  $(".btn-search, .input-search-box").hover(
    function () {
      $(".input-search-box").addClass("active");
    },
    function(){
      setTimeout(() => {
        if (!$(".btn-search:hover, .input-search-box:hover").length) {
          $(".input-search-box").removeClass("active");
        }
      }, 500);
    }
  );
  /* Header Search Icon Click Relative Code End */

  /* Cover Flow Plugin Slider - Relative code Start - (https://www.jqueryscript.net/slideshow/Responsive-Image-Cover-Flow-Plugin-with-jQuery-CSS3-flipster.html) */
  $("#coverflow").flipster({
    style: 'coverflow',
    loop: true,
  });
  /* Cover Flow Plugin Slider - Relative code End */

  /* Image Click Open - Magnific Popup - Relative Code Start */
  if ($(".gallery-group-container").length) {
    $(".gallery-group-container").each(function (index) {
      let galleryClass = "gallery-" + index; // Unique class for each gallery
      $(this).find('.gallery-link').addClass(galleryClass); // Add class to all images in this slider
      $('.' + galleryClass).magnificPopup({
        type: 'image',
        removalDelay: 300,
        closeOnBgClick: false,
        enableEscapeKey: false,
        mainClass: 'mfp-fade',
        gallery: {
          enabled: true,
          navigateByImgClick: true,
          arrowMarkup: `
            <button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%">
              <i class="fa-solid fa-chevron-%dir%"></i>
            </button>`
        },
      });
    });
  }
  /* Image Click Open - Magnific Popup - Relative Code End */

  /* Animation - Relative Code Start */
  AOS.init({
    duration: 800,
    offset: 100,
    once: true,
    easing: 'ease-out-cubic',
    mirror: false,
  });
  /* Animation - Relative Code End */
});