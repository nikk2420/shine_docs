$(document).ready(function () {
  /* *********************************** Owl Carousel Slider - Relative Code Start *********************************** */

  /* Banner Carousel - Relative Code Start */
  if ($(".owl-banner-image-carousel .owl-carousel").length) {
    $('.owl-banner-image-carousel .owl-carousel').owlCarousel({
      loop: false,
      margin: 8,
      autoplay: false,
      autoplayHoverPause: true,
      autoplayTimeout: 4000,
      smartSpeed: 600,
      nav: true,
      dots: true,
      items: 1,
    });
    $(".owl-banner-image-carousel .owl-carousel .owl-prev").html('<i class="fa-solid fa-chevron-left"></i>');
    $(".owl-banner-image-carousel .owl-carousel .owl-next").html('<i class="fa-solid fa-chevron-right"></i>');
  }
  /* Banner Carousel - Relative Code End */

  /* Card Detail Carousel - Relative Code Start */
  if ($(".owl-card-detail-carousel .owl-carousel").length) {
    $('.owl-card-detail-carousel .owl-carousel').owlCarousel({
      loop: true,
      margin: 22,
      autoplay: true,
      autoplayHoverPause: true,
      autoplayTimeout: 3000,
      smartSpeed: 3000,
      nav: false,
      dots: false,
      mouseDrag: false,
      touchDrag: false,
      pullDrag: false,
      responsive:{
        0:{
          items: 1,
          margin: 0,
          autoplay: false,
        },
        576: {
          items: 1.18,
          autoplay: true,
          autoplayHoverPause: true,
          autoplayTimeout: 3000,
          smartSpeed: 3000,
          margin: 22,
        },
        767: {
          items: 2.18,
        },
        992: {
          items: 3.18,
        },
        1200: {
          items: 4.18
        },
      }
    });
    $(".owl-card-detail-carousel .owl-carousel .owl-prev").html('<i class="fa fa-long-arrow-left" aria-hidden="true"></i>');
    $(".owl-card-detail-carousel .owl-carousel .owl-next").html('<i class="fa fa-long-arrow-right" aria-hidden="true"></i>');
  }
  /* Card Detail Carousel - Relative Code End */

  /* Upcoming Carousel - Relative Code Start */
  if ($(".owl-card-slider-view-carousel .owl-carousel").length) {
    $('.owl-card-slider-view-carousel .owl-carousel').owlCarousel({
      loop: true,
      margin: 22,
      autoplay: true,
      autoplayHoverPause: true,
      autoplayTimeout: 3000,
      smartSpeed: 3000,
      nav: false,
      dots: false,
      mouseDrag: false,
      touchDrag: false,
      pullDrag: false,
      responsive:{
        0:{
          items: 1,
          margin: 0,
        },
        768: {
          items: 1.5,
          margin: 22,
        },
        992: {
          items: 2.5
        },
        1200: {
          items: 2.5
        }
      }
    });
    $(".owl-card-slider-view-carousel .owl-carousel .owl-prev").html('<i class="fa fa-long-arrow-left" aria-hidden="true"></i>');
    $(".owl-card-slider-view-carousel .owl-carousel .owl-next").html('<i class="fa fa-long-arrow-right" aria-hidden="true"></i>');
  }
  /* Upcoming Carousel - Relative Code End */

  /* Shri Hari Mandir Carousel - Relative Code Start */
  if ($(".owl-shri-hari-mandir-darshan-carousel .owl-carousel").length) {
    $('.owl-shri-hari-mandir-darshan-carousel .owl-carousel').owlCarousel({
      loop: true,
      margin: 25,
      autoplay: true,
      autoplayHoverPause: true,
      autoplayTimeout: 4000,
      smartSpeed: 600,
      nav: true,
      mouseDrag: false,
      touchDrag: false,
      pullDrag: false,
      dots: false,
      // rewind: false,
      responsive:{
        0:{
          items: 1
        },
        420: {
          items: 1
        },
        576: {
          items: 1
        },
        768: {
          items: 2
        },
        992: {
          items: 2
        },
        1200: {
          items: 2
        }
      }
    });
    $(".owl-shri-hari-mandir-darshan-carousel .owl-carousel .owl-prev").html('<i class="fa-solid fa-chevron-left"></i>');
    $(".owl-shri-hari-mandir-darshan-carousel .owl-carousel .owl-next").html('<i class="fa-solid fa-chevron-right"></i>');
  }
  /* Shri Hari Mandir Carousel - Relative Code End */

  /* *********************************** Owl Carousel Slider - Relative Code End *********************************** */

  /* *********************************** Slick Slider - Relative Code Start *********************************** */
  if ($(".vision-of-sandipani-slick-slider").length) {
    $('.vision-of-sandipani-slick-slider').slick({
      draggable: true,
      centerMode: true,
      autoplay: true,
      autoplaySpeed: 3000,
      arrows: false,
      dots: false,
      fade: false,
      speed: 500,
      infinite: true,
      cssEase: 'linear',
      slidesToScroll: 1,
      slidesToShow: 3,
      variableWidth: true
    });
  }
  // function updateSlideSizes() {
  //   $('.vision-of-sandipani-slick-slider .slick-slide').css({
  //     transform: 'scale(0.8)',
  //     opacity: 0.6,
  //     transition: 'all 0.3s ease'
  //   });
  //   $('.vision-of-sandipani-slick-slider .slick-slide.slick-center').css({
  //     transform: 'scale(1)',
  //     opacity: 1,
  //     zIndex: 2
  //   });
  // }
  // $('.vision-of-sandipani-slick-slider').on('init reInit afterChange', function () {
  //   updateSlideSizes();
  // });
  // updateSlideSizes();

  $('.slick-prev').click(function() {
    $('.vision-of-sandipani-slick-slider').slick('slickPrev');
  });
  $('.slick-next').click(function() {
    $('.vision-of-sandipani-slick-slider').slick('slickNext');
  });
  /* *********************************** Slick Slider - Relative Code End *********************************** */

  /* *********************************** Swiper Slider - Relative Code Start *********************************** */
  /* Image with Dot Slider - Relative Code Start */
  if ($(".swiper.dynamic-bullets").length) {
    new Swiper('.swiper.dynamic-bullets', {
      slidesPerView : 1,
      slidesPerGroup: 1,
      loop: true,
      spaceBetween: 20,
      speed: 1000,
      pagination: {
        el: ".swiper-pagination",
        dynamicBullets: true,
        clickable: true
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  }
  /* Image with Dot Slider - Relative Code End */
  /* *********************************** Swiper Slider - Relative Code End *********************************** */

});