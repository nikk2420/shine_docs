function addCarouselImage(sectionId) {
    const imageIndex = Date.now();
    const container = document.getElementById(`carousel-images-${sectionId}`);

    const html = `
    <div class="carousel-image-item border rounded p-2 mb-3 position-relative">
        <button type="button" class="btn btn-sm btn-danger float-right top-0 end-0 m-1" onclick="this.parentElement.remove()">
            &times;
        </button>
        
        <div class="form-group">
            <label>Upload Image</label>
            <input type="file" name="sections[${sectionId}][images][${imageIndex}][file]" class="form-control">
        </div>
        <div class="form-group">
            <label>Image Description</label>
            <textarea name="sections[${sectionId}][images][${imageIndex}][description]" class="form-control"></textarea>
        </div>
    </div>
    `;

    container.insertAdjacentHTML('beforeend', html);
}

function addSection(type) {
    let html = '';
    const sectionId = Date.now(); // unique ID for each block

    if (type === 'title') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span>Title Section</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="title">
                <div class="form-group col-md-6">
                    <label>Title</label>
                    <input type="text" name="sections[${sectionId}][title]" class="form-control">
                </div>
            </div>
        </div>`;
    }

    else if (type === 'title_with_description') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                <span>Title with Description</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="title_with_description">
                <div class="form-group col-md-6">
                    <label>Title</label>
                    <input type="text" name="sections[${sectionId}][title]" class="form-control">
                </div>
                <div class="form-group col-md-12">
                    <label>Description</label>
                    <textarea name="sections[${sectionId}][content]" class="form-control rich-editor" id="richEditor"></textarea>
                </div>
            </div>
        </div>`;
    }

    else if (type === 'content_with_bg') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                <span>Content with Background Color</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="content_with_bg">
                <div class="form-group">
                    <label>Content</label>
                    <textarea name="sections[${sectionId}][content]" class="form-control rich-editor" id="richEditor"></textarea>
                </div>
                <div class="form-group col-md-4">
                    <label>Background Color</label>
                    <input type="color" name="sections[${sectionId}][background_color]" class="form-control" style="height: 50px;">
                </div>
            </div>
        </div>`;
    }

    else if (type === 'image_with_description') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                <span>Image/Video with Description</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="image_with_description">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="sections[${sectionId}][title]" class="form-control">
                </div>
                <div class="form-group">
                    <label>Upload Image/Video</label>
                    <input type="file" name="sections[${sectionId}][image]" class="form-control">
                </div>
                <div class="form-group">
                    <label>Image/Video Description</label>
                    <textarea name="sections[${sectionId}][image_description]" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>Content</label>
                    <textarea name="sections[${sectionId}][content]" class="form-control rich-editor" id="richEditor"></textarea>
                </div>
                <div class="form-group">
                    <label>Image/Video Position</label>
                    <select name="sections[${sectionId}][position]" class="form-control">
                        <option value="left">Left</option>
                        <option value="right">Right</option>
                    </select>
                </div>
            </div>
        </div>`;
    }

    else if (type === 'single_video_with_description') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                <span>Single Image/Video with Description</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="single_video_with_description">
                <div class="form-group">
                    <label>Upload image/Video</label>
                    <input type="file" name="sections[${sectionId}][image]" class="form-control">
                </div>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="sections[${sectionId}][title]" class="form-control">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="sections[${sectionId}][content]" class="form-control rich-editor" id="richEditor"></textarea>
                </div>
            </div>
        </div>`;
    }

    else if (type === 'faq') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                <span>FAQs Section</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="faq">
                <div class="faq-item">
                    <div class="form-group">
                        <label>Question</label>
                        <input type="text" name="sections[${sectionId}][title]" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Answer</label>
                        <textarea name="sections[${sectionId}][content]" class="form-control rich-editor" id="richEditor"></textarea>
                    </div>
                </div>
            </div>
        </div>`;
    }

    else if (type === 'image_carousel') {
        html = `
        <div class="card mb-4 p-3 shadow section-block border position-relative" id="section-${sectionId}">
            <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                <span>Image Carousel</span>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeSection('section-${sectionId}')">
                    &times;
                </button>
            </div>
            <div class="card-body">
                <input type="hidden" name="sections[${sectionId}][section_type]" value="image_carousel">
                
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="sections[${sectionId}][title]" class="form-control">
                </div>

                <div class="image-carousel-items" id="carousel-images-${sectionId}">
                    <!-- Images will be added here -->
                </div>

                <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addCarouselImage(${sectionId})">+ Add Image</button>
            </div>
        </div>`;
    }

    $('#content-sections').append(html);

    // // Initialize CKEditor for new editors
    // setTimeout(() => {
    //     document.querySelectorAll('.rich-editor').forEach(textarea => {
    //         if (!textarea.classList.contains('ckeditor-applied')) {
    //             CKEDITOR.replace(textarea);
    //             textarea.classList.add('ckeditor-applied');
    //         }
    //     });
    // }, 100);
    var editor = new FroalaEditor('#richEditor'); 
}

function removeSection(id) {
    const section = document.getElementById(id);
    if (section) {
        section.remove();
    }
}