<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class ApiService
{
    protected $baseUrl;
    protected $email;
    protected $password;

    public function __construct()
    {
        $this->baseUrl = config('services.external_api.url');
        $this->email = config('services.external_api.email');
        $this->password = config('services.external_api.password');
    }

    // Get token and cache it
    public function getToken()
    {
        if (Cache::has('api_jwt_token')) {
            return Cache::get('api_jwt_token');
        }

        $response = Http::post("{$this->baseUrl}/login", [
            'email' => $this->email,
            'password' => $this->password,
        ]);

        if ($response->successful() && isset($response['data']['token'])) {
            $token = $response['data']['token'];
            // Cache token for 1 hour (or set based on your JWT expiry)
            Cache::put('api_jwt_token', $token, now()->addMinutes(55));
            return $token;
        }

        throw new \Exception('API Authentication Failed: ' . $response->body());
    }

    // Example: GET request with token
    public function get($endpoint, $params = [])
    {
        $token = $this->getToken();

        $response = Http::withToken($token)
                        ->get("{$this->baseUrl}/{$endpoint}", $params);

        if ($response->unauthorized()) {
            Cache::forget('api_jwt_token'); // Token might be expired or revoked
            return $this->get($endpoint, $params); // Retry once
        }

        return $response->json();
    }

    // POST method
    public function post($endpoint, $data = [])
    {
        $token = $this->getToken();

        $response = Http::withToken($token)
                        ->post("{$this->baseUrl}/{$endpoint}", $data);

        if ($response->unauthorized()) {
            Cache::forget('api_jwt_token');
            return $this->post($endpoint, $data);
        }

        return $response->json();
    }

    public function downloadExcel($endpoint, $params = [])
    {
        $token = $this->getToken();

        $response = Http::withToken($token)
                        ->withHeaders([
                            'Accept' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        ])
                        ->get("{$this->baseUrl}/{$endpoint}", $params);

        if ($response->unauthorized()) {
            Cache::forget('api_jwt_token');
            return $this->downloadExcel($endpoint, $params);
        }

        if (!$response->successful()) {
            throw new \Exception('Failed to download file: ' . $response->body());
        }

        return $response;
    }

    public function downloadPDF($endpoint)
    {
        $token = $this->getToken();

        $response = Http::withToken($token)
                        ->get("{$this->baseUrl}/{$endpoint}");

        if ($response->unauthorized()) {
            Cache::forget('api_jwt_token');
            return $this->downloadPDF($endpoint);
        }

        return $response;
    }

    // You can add `post`, `put`, `delete` methods similarly
}
