<?php

use App\Models\ActivityLog;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

if (!function_exists('safe_decrypt')) {
    function safe_decrypt($encryptedId)
    {
        try {
            return Crypt::decrypt($encryptedId);
        } catch (DecryptException $e) {
            abort(404); // Invalid or tampered ID
        }
    }
}

if (!function_exists('safe_encrypt')) {
    function safe_encrypt($value)
    {
        return Crypt::encrypt($value);
    }
}

if (!function_exists('activityLog')) {
    function activityLog($action, $description = null, $email = null)
    {
        ActivityLog::create([
            'user_id'    => Auth::id(),
            'email'      => $email ?? Auth::user()->email,
            'action'     => $action,
            'description'=> $description,
            'ip'         => Request::ip(),
            'user_agent' => Request::header('User-Agent'),
        ]);
    }
}

if (!function_exists('can_access')) {
    function can_access(string $module, string $action = 'view'): bool
    {
        $user = Auth::user();
        return $user && $user->hasPermission($module, $action);
    }
}