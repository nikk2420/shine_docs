<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'role_id',
        'active_institute',
        'email_verified_at',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    protected $appends = ['role_name', 'role_status', 'permissions_list'];

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function getRoleNameAttribute()
    {
        return $this->role?->name;
    }

    public function getRoleStatusAttribute()
    {
        return $this->role?->is_active;
    }
    
    public function getPermissionsListAttribute()
    {
        return $this->role?->permissions ?? collect();
    }

    public function hasPermission(string $module, string $action = 'view'): bool
    {
        $actionColumn = match ($action) {
            'view' => 'can_view',
            'add' => 'can_add',
            'update' => 'can_update',
            'delete' => 'can_delete',
            default => null,
        };

        if (!$actionColumn) {
            return false;
        }

        return $this->permissions_list->contains(function ($permission) use ($module, $actionColumn) {
            return $permission->module === $module && $permission->{$actionColumn};
        });
    }

    public function assignedInstitutes()
    {
        return $this->belongsToMany(Institute::class, 'user_institute');
    }

    public function activeInstitute()
    {
        return $this->belongsTo(Institute::class, 'active_institute');
    }



}
