<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    protected $fillable = [
        'role_id',
        'module',
        'can_view',
        'can_add',
        'can_update',
        'can_delete',
    ];

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

}
