<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CmsHeader extends Model
{
    protected $fillable = ['institute_id', 'title', 'link', 'type', 'slug', 'order', 'is_active'];

    public function institute()
    {
        return $this->belongsTo(Institute::class);
    }
}
