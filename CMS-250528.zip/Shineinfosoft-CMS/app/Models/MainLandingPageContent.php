<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MainLandingPageContent extends Model
{
    use HasFactory;

    protected $fillable = [
        'section_type',
        'title',
        'content',
        'background_color',
        'image_path',
        'image_position',
        'image_description',
        'order_no',
    ];

    public function media()
    {
        return $this->morphMany(ContentMedia::class, 'mediaable');
    }
}
