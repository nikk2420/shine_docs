<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MainHeader extends Model
{
    protected $fillable = ['title', 'link', 'type', 'slug', 'order', 'is_active'];
}
