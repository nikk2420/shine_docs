<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContentMedia extends Model
{
    use HasFactory;

    protected $fillable = [
        'media_type',         // 'image' or 'video'
        'media_path',         // local path or video URL
        'media_position',
        'media_description',
        'order_no',
    ];
    
    public function mediaable()
    {
        return $this->morphTo();
    }

    public function scopeImages($query)
    {
        return $query->where('media_type', 'image');
    }

    public function scopeVideos($query)
    {
        return $query->where('media_type', 'video');
    }
}
