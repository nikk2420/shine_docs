<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MainFooter extends Model
{
    protected $fillable = ['title', 'link', 'type', 'slug', 'order', 'is_active'];
}
