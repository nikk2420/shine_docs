<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MainMenu extends Model
{
    protected $fillable = [
        'parent_id', 
        'title', 
        'slug', 
        'url', 
        'order_no', 
        'is_active', 
        'show_on_website'
    ];

    public function parent()
    {
        return $this->belongsTo(MainMenu::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(MainMenu::class, 'parent_id')->with('children')->orderBy('order_no');
    }
}
