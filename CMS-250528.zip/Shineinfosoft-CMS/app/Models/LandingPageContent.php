<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingPageContent extends Model
{
    use HasFactory;

    protected $fillable = [
        'institute_id',
        'section_type',
        'title',
        'content',
        'background_color',
        'image_path',
        'image_position',
        'image_description',
        'order_no',
    ];

    public function institute()
    {
        return $this->belongsTo(Institute::class);
    }

    public function media()
    {
        return $this->morphMany(ContentMedia::class, 'mediaable');
    }
}
