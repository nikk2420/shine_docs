<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Institute extends Model
{
    public function menus()
    {
        return $this->hasMany(Menu::class)->whereNull('parent_id')->with('children');
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'user_institute');
    }
}
