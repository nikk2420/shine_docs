<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PageContent extends Model
{
    use HasFactory;

    protected $fillable = [
        'menu_id',
        'section_type',
        'title',
        'content',
        'background_color',
        'image_path',
        'image_position',
        'image_description',
        'order_no',
    ];

    public function menu()
    {
        return $this->belongsTo(Menu::class);
    }

    public function media()
    {
        return $this->morphMany(ContentMedia::class, 'mediaable');
    }
}
