<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use App\Mail\ForgotPasswordOTP;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class ForgotPasswordController extends Controller
{
    
    public function forgotPassword(Request $request)
    {
        return view('admin.auth.forgot-password');
    }

    public function sendOTP(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            // Check if the email exists
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return redirect()->back()->withErrors(['error' => 'This email is not registered in our system.']);
            }

            // Generate a 4-digit OTP
            $otp = mt_rand(1000, 9999);
            $expiresAt = now()->addMinutes(10); // OTP expires in 10 minutes

            // Store OTP in a new table (or user table with expiry)
            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $user->email],
                ['token' => $otp, 'created_at' => now(), 'is_verified' => false]
            );

            // Send OTP via email
            $status = Mail::to($user->email)->send(new ForgotPasswordOTP($otp));

            return redirect()->route('admin.verify.otp', ['email' => $request->email])->with('success','Reset OTP sent to your email.');

        } catch (\Exception $e) {
            Log::error('send OTP Error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function reSendOTP(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            // Check if the email exists
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return redirect()->route('admin.login')->withErrors(['error' => 'Given email is not registered in our system.']);
            }

            // Generate a 4-digit OTP
            $otp = mt_rand(1000, 9999);
            $expiresAt = now()->addMinutes(10); // OTP expires in 10 minutes

            // Store OTP in a new table (or user table with expiry)
            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $user->email],
                ['token' => $otp, 'created_at' => now(), 'is_verified' => false]
            );

            // Send OTP via email
            $status = Mail::to($user->email)->send(new ForgotPasswordOTP($otp));

            return redirect()->route('admin.verify.otp', ['email' => $request->email])->with('success','OTP resent to your email.');

        } catch (\Exception $e) {
            Log::error('send OTP Error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function verifyOtp(Request $request)
    {
        $email = request('email');

        return view('admin.auth.verify-otp', compact('email'));
    }

    public function checkOtpValidation(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'otp' => 'required',
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            $otp = implode('', $request->otp);

            // Check if the email exists
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return redirect()->back()->withErrors(['error' => 'This email is not registered in our system.']);
            }

            // Find OTP record that is not older than 10 minutes
            $otpRecord = DB::table('password_reset_tokens')
                ->where('email', $request->email)
                ->where('token', $otp)
                ->where('created_at', '>=', now()->subMinutes(10))
                ->first();

            if (!$otpRecord) {
                return redirect()->back()->withErrors(['error' => 'Invalid or expired OTP.']);
            }

            // If not already verified, update it
            if (!$otpRecord->is_verified) {
                DB::table('password_reset_tokens')
                    ->where('email', $request->email)
                    ->where('token', $otp)
                    ->update(['is_verified' => true]);
            }

            return redirect()->route('admin.reset.password', ['email' => $request->email])->with('success','OTP verified successfully.');

        } catch (\Exception $e) {
            Log::error('OTP Verification Error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function resetPassword(Request $request)
    {
        $email = request('email');

        return view('admin.auth.reset-password', compact('email'));
    }

    public function updatePassword(Request $request)
    {
        try{

            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => [
                    'required',
                    'string',
                    'min:8',
                    'max:16',
                    'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,16}$/',
                    'confirmed'
                ],
            ],[
                'password.regex' => 'Password must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.',
                'password.confirmed' => 'The password confirmation does not match.',
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            // Check if the email exists
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return redirect()->back()->withErrors(['error' => 'This email is not registered in our system.']);
            }

            // Ensure OTP exists for security purposes
            $otpRecord = DB::table('password_reset_tokens')
                ->where('email', $request->email)
                ->where('is_verified', true)
                ->where('created_at', '>=', now()->subMinutes(10)) // Check if OTP is recent
                ->exists();

            if (!$otpRecord) {
                activityLog('Password-Reset','OTP verification required before resetting the password.',$request->email);
                return redirect()->back()->withErrors(['error' => 'OTP verification required before resetting the password.']);
            }

            // Reset password
            $user->forceFill([
                'password' => Hash::make($request->password),
            ])->save();

            // Delete OTP after successful password reset
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();
            activityLog('Password-Reset','Password has been reset.',$request->email);

            return redirect()->route('admin.login')->with('success','Password has been reset.');

        } catch (\Exception $e) {
            Log::error('Reset Password Error:' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
