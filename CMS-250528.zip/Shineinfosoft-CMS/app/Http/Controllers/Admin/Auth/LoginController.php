<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Validator;

class LoginController extends Controller
{
    public function showLoginForm(Request $request)
    {
        if(isset(Auth::user()->id)){
            return redirect()->route('admin.dashboard');
        }

        return view('admin.auth.login');
    }

    public function login(Request $request)
    {
        try{
            // Throttle login attempts
            $throttleKey = $request->ip();
            $throttle = RateLimiter::for('login', function ($throttleKey) {
                return Limit::perMinute(5)->by($throttleKey);
            });
            
            if ($throttle->tooManyAttempts($throttleKey, 5)) {
                return redirect()->back()
                    ->withErrors(['error' => 'Too many login attempts. Please try again in ' . 
                        $throttle->availableIn($throttleKey) . ' seconds.'])
                    ->withInput();
            }

            $validator = Validator::make($request->all(), [
                'email' => 'required|email|exists:users,email',
                'password' => 'required',
            ]);

            if ($validator->fails()) {
                activityLog('User-Login',$validator->errors(),$request->email);
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            $credentials = $request->only('email', 'password');
            $remember = $request->has('remember');

            if (Auth::attempt($credentials, $remember)) {

                // Check if the user has a role assigned
                $user = Auth::user();
                if (empty($user->role_id)) {
                    activityLog('User-Login','Role not assigned to user so that not permitted to access dashboard!',$request->email);
                    Auth::logout();
                    return redirect()->route('admin.login')
                        ->withErrors(['error' => 'Role not assigned to you. Please connect with administrator.'])
                        ->withInput();
                } else if ($user->role_status !== 1){
                    activityLog('User-Login','Assigned role status not active!',$request->email);
                    Auth::logout();
                    return redirect()->route('admin.login')
                        ->withErrors(['error' => 'Assigned role status not active! Please connect with administrator.'])
                        ->withInput();
                }

                activityLog('User-Login','User Logged In Successfully.',$request->email);
                return redirect()->route('admin.dashboard')->with('success','Login Successfully');
            }else{
                $throttle->hit($throttleKey);
            }

            activityLog('User-Login','The provided credentials do not match our records',$request->email);
            return redirect()->back()
                ->withErrors(['error' => 'The provided credentials do not match our records.'])
                ->withInput();

        } catch (\Exception $e) {
            Log::error('Login Error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function logout(Request $request)
    {
        try{
            
            $user = Auth::user();
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            activityLog('User-logout','User Logged Out.',$user->email);
            return redirect()->route('admin.login')->with('success','Successfully logout');

        } catch (\Exception $e) {
            Log::error('Logout Error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

}
