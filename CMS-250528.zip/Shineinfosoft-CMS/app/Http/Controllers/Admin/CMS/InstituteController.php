<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\Institute;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class InstituteController extends Controller
{
    public function setActiveInstitute(Request $request)
    {
        // $request->validate([
        //     'acive_institute' => 'nullable|exists:institutes,id',
        // ]);

        // // Check if selected institute is assigned to user
        // if ($request->acive_institute && !$user->assignedInstitutes->pluck('id')->contains($request->acive_institute)) {
        //     return redirect()->back()->withErrors(['error' => 'Unauthorized institute selection.']);
        // }

        $user = Auth::user();

        $user->active_institute = $request->acive_institute;
        $user->save();

        return redirect()->back()->with('success', 'Active institute changed successfully.');
    }
}
