<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\CmsFooter;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class FooterController extends Controller
{
    public function index()
    {
        $auth = Auth::user();
        $institute_id = $auth->active_institute;

        $footerItems = CmsFooter::where('institute_id', $institute_id)
            // ->where('is_active', 1)
            ->orderBy('order')
            ->get();

        return view('admin.cms.footer.index', compact('footerItems'));
    }
    
    public function footerStore(Request $request)
    {
        $auth = Auth::user();

        CmsFooter::create([
            'institute_id' => $auth->active_institute,
            'title' => $request->title,
            'link' => $request->link ?? null,
            'type' => $request->type ?? 'link',
            'slug' => $request->slug ?? null,
            'is_active' => $request->is_active ?? 1
        ]);

        return redirect()->route('admin.cms.footer')->with('success', 'Footer updated successfully!');
    }

    public function toggleSectionStatus(Request $request, $id)
    {
        $section = CmsFooter::findOrFail($id);
        $section->is_active = $request->is_active;
        $section->save();

        return response()->json([
            'success' => true,
            'message' => $request->is_active ? 'Section activated successfully.' : 'Section deactivated successfully.'
        ]);
    }

    public function updateOrder(Request $request)
    {
        foreach ($request->order as $item) {
            CmsFooter::where('id', $item['id'])->update(['order' => $item['order_no']]);
        }

        return response()->json(['success' => true]);
    }

    public function edit(Request $request, $sectionId)
    {        
        try {
            $auth = Auth::user();
            $sectionId = safe_decrypt($sectionId);

            $section = CmsFooter::findOrFail($sectionId);

            return view('admin.cms.footer.edit', compact('section'));

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Edit Footer Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function updateFooter(Request $request, $sectionId)
    {
        try {
            $auth = Auth::user();
            $sectionId = safe_decrypt($sectionId);
            $data = [];

            $section = CmsFooter::findOrFail($sectionId);

            if ($request->has('title')) {
                $data['title'] = $request->input('title');
            }

            if ($request->has('link')) {
                $data['link'] = $request->input('link');
            }

            if ($request->has('type')) {
                $data['type'] = $request->input('type');
            }

            if ($request->has('slug')) {
                $data['slug'] = $request->input('slug');
            }

            if ($request->has('is_active')) {
                $data['is_active'] =  1;
            }else{
                $data['is_active'] =  0;
            }

            $section->update($data);

            return redirect()->route('admin.cms.footer')->with('success', 'Section updated successfully.');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Footer Section Content Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function destroySection(Request $request)
    {
        try {
            $data = CmsFooter::findOrFail($request->id);

            $data->delete();

            activityLog('Footer-Section', 'Footer Section Deleted Successfully');

            return redirect()->back()->with('success','Section Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Footer Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
