<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\ContentMedia;
use App\Models\LandingPageContent;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class LandingPageController extends Controller
{
    public function index()
    {
        $auth = Auth::user();

        $exists = LandingPageContent::where('institute_id', $auth->active_institute)->exists();

        return view('admin.cms.landing_page.index', compact('exists'));
    }

    public function contentsCreate(Request $request)
    {
        try{
            if(isset($request->institute_id) && !empty($request->institute_id)){
                foreach ($request->sections as $order => $section) {
                    $imagePath = null;

                    if (!empty($section['image'])) {
                        $imagePath = $section['image']->store('uploads/content', 'public');
                    }

                    $content = LandingPageContent::create([
                        'institute_id' => $request->institute_id,
                        'section_type' => $section['section_type'],
                        'title' => $section['title'] ?? null,
                        'content' => $section['content'] ?? null,
                        'background_color' => $section['background_color'] ?? null,
                        'image_path' => $imagePath,
                        'image_position' => $section['position'] ?? null,
                        'image_description' => $section['image_description'] ?? null,
                        // 'order_no' => $order,
                    ]);

                    if(!empty($section['images'])){
                        foreach ($section['images'] ?? [] as $imageData) {
                            if (isset($imageData['file'])) {
                                $path = $imageData['file']->store('uploads/media', 'public');

                                $content->media()->create([
                                    'media_type' => 'image',
                                    'media_path' => $path,
                                    'media_description' => $imageData['description'] ?? null,
                                ]);
                            }
                        }
                    }
                }

                return redirect()->route('admin.cms.landing.page')->with('success','Page Content Set Successfully');

            }else{
                return redirect()->route('admin.cms.landing.page')->with('error','Active Institute not found!');
            }
            
        } catch (\Exception $e) {
            Log::error('Landing Page Content Create Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function manageContent($instituteId)
    {
        $auth = Auth::user();
        $instituteId = safe_decrypt($instituteId);
        $content = LandingPageContent::with(['media' => fn($q) => $q->orderBy('order_no')])
                    ->where('institute_id', $instituteId)
                    ->orderBy('order_no')
                    ->get();

        return view('admin.cms.landing_page.manage_content', compact('content','instituteId'));
    }

    public function editContent(Request $request, $contentId)
    {        
        try {
            $auth = Auth::user();
            $contentId = safe_decrypt($contentId);

            $section = LandingPageContent::with(['media' => fn($q) => $q->orderBy('order_no')])->findOrFail($contentId);

            // $menu = Menu::where('id', $section->menu_id)->where('institute_id', $auth->active_institute)->with('parent')->first();

            return view('admin.cms.landing_page.edit_content', compact('section'));

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Edit Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function contentUpdate(Request $request, $contentId)
    {
        try {
            $auth = Auth::user();
            $contentId = safe_decrypt($contentId);
            $data = [];

            $section = LandingPageContent::findOrFail($contentId);

            if ($request->has('title')) {
                $data['title'] = $request->input('title');
            }

            if ($request->has('content')) {
                $data['content'] = $request->input('content');
            }

            if ($request->has('background_color')) {
                $data['background_color'] = $request->input('background_color');
            }

            if ($request->has('image_description')) {
                $data['image_description'] = $request->input('image_description');
            }

            if ($request->has('position')) {
                $data['image_position'] = $request->input('position');
            }

            // Handle optional image/video upload
            if (!empty($request->file('image'))) {
                $imagePath = $request->file('image')->store('uploads/content', 'public');
                $data['image_path'] = $imagePath;
            }

            // Update the section with only available data
            $section->update($data);

            // update existing image
            if($request->has('exist_images')){
                foreach ($request->exist_images ?? [] as $key => $imageData) {
                    $media = ContentMedia::findOrFail($key);
                    $media_data = [];

                    if($media){
                        if (isset($imageData['file'])) {
                            $media_data['media_type'] = 'image';
                            $media_data['media_path'] = $imageData['file']->store('uploads/media', 'public');
                        }

                        $media_data['media_description'] = $imageData['description'] ?? null;

                        $media->update($media_data);
                    }
                }
            }

            // upload new image
            if($request->has('images')){
                foreach ($request->images ?? [] as $imageData) {
                    if (isset($imageData['file'])) {
                        $path = $imageData['file']->store('uploads/media', 'public');

                        $section->media()->create([
                            'media_type' => 'image',
                            'media_path' => $path,
                            'media_description' => $imageData['description'] ?? null,
                        ]);
                    }
                }
            }

            return redirect()->route('admin.cms.landing.page.content.manage', ['instituteId' => safe_encrypt($section->institute_id)])->with('success', 'Section updated successfully.');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Landing Page Section Content Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function updateOrder(Request $request)
    {
        foreach ($request->order as $item) {
            LandingPageContent::where('id', $item['id'])->update(['order_no' => $item['order_no']]);
        }

        return response()->json(['success' => true]);
    }

    public function updateMediaOrder(Request $request)
    {
        foreach ($request->order as $item) {
            ContentMedia::where('id', $item['id'])->update(['order_no' => $item['order_no']]);
        }

        return response()->json(['success' => true]);
    }
    
    public function destroySection(Request $request)
    {
        try {
            $data = LandingPageContent::findOrFail($request->id);

            $data->delete();

            activityLog('Landing-Page-Section', 'Landing Page Section Deleted Successfully');

            return redirect()->back()->with('success','Section Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Landing Page Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function destroyMediaSection(Request $request)
    {
        try {
            $data = ContentMedia::findOrFail($request->id);

            $data->delete();

            activityLog('Landing-Page-Carousel-Section', 'Landing Page Carousel Section Deleted Successfully');

            return redirect()->back()->with('success','Section Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Landing Page Carousel Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
