<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\CmsFooter;
use App\Models\CmsHeader;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class HeaderController extends Controller
{
    public function index()
    {
        $auth = Auth::user();
        $institute_id = $auth->active_institute;
        
        $headerItems = CmsHeader::where('institute_id', $institute_id)
            // ->where('is_active', 1)
            ->orderBy('order')
            ->get();

        return view('admin.cms.header.index', compact('headerItems'));
    }

    public function headerStore(Request $request)
    {
        $auth = Auth::user();

        CmsHeader::create([
            'institute_id' => $auth->active_institute,
            'title' => $request->title,
            'link' => $request->link ?? null,
            'type' => $request->type ?? 'link',
            'slug' => $request->slug ?? null,
            'is_active' => $request->is_active ?? 1
        ]);

        return redirect()->route('admin.cms.header')->with('success', 'Header updated successfully!');
    }

    public function toggleSectionStatus(Request $request, $id)
    {
        $section = CmsHeader::findOrFail($id);
        $section->is_active = $request->is_active;
        $section->save();

        return response()->json([
            'success' => true,
            'message' => $request->is_active ? 'Section activated successfully.' : 'Section deactivated successfully.'
        ]);
    }

    public function updateOrder(Request $request)
    {
        foreach ($request->order as $item) {
            CmsHeader::where('id', $item['id'])->update(['order' => $item['order_no']]);
        }

        return response()->json(['success' => true]);
    }

    public function edit(Request $request, $sectionId)
    {        
        try {
            $auth = Auth::user();
            $sectionId = safe_decrypt($sectionId);

            $section = CmsHeader::findOrFail($sectionId);

            return view('admin.cms.header.edit', compact('section'));

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Edit Header Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function updateHeader(Request $request, $sectionId)
    {
        try {
            $auth = Auth::user();
            $sectionId = safe_decrypt($sectionId);
            $data = [];

            $section = CmsHeader::findOrFail($sectionId);

            if ($request->has('title')) {
                $data['title'] = $request->input('title');
            }

            if ($request->has('link')) {
                $data['link'] = $request->input('link');
            }

            if ($request->has('type')) {
                $data['type'] = $request->input('type');
            }

            if ($request->has('slug')) {
                $data['slug'] = $request->input('slug');
            }

            if ($request->has('is_active')) {
                $data['is_active'] =  1;
            }else{
                $data['is_active'] =  0;
            }

            $section->update($data);

            return redirect()->route('admin.cms.header')->with('success', 'Section updated successfully.');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Header Section Content Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function destroySection(Request $request)
    {
        try {
            $data = CmsHeader::findOrFail($request->id);

            $data->delete();

            activityLog('Header-Section', 'Header Section Deleted Successfully');

            return redirect()->back()->with('success','Section Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Header Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

}
