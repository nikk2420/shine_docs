<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\PageContent;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ContentController extends Controller
{
    public function contentsView()
    {
        $auth = Auth::user();

        $menus = Menu::where('institute_id', $auth->active_institute)
            ->whereNull('parent_id')
            ->where('show_on_website', true)
            // ->with(['children' => function ($q) {
            //     $q->where('show_on_website', true);
            // }])
            ->orderBy('order_no')
            ->get();

        return view('admin.cms.contents', compact('menus'));
    }

    public function contentsCreate(Request $request)
    {
        try{
            if($request->child_menu){
                $menuID = $request->child_menu;
            }else if($request->submenu){
                $menuID = $request->submenu;
            }else{
                $menuID = $request->main_menu;
            }
            
            foreach ($request->sections as $order => $section) {
                $imagePath = null;

                if (!empty($section['image'])) {
                    $imagePath = $section['image']->store('uploads/content', 'public');
                }

                PageContent::create([
                    'menu_id' => $menuID,
                    'section_type' => $section['section_type'],
                    'title' => $section['title'] ?? null,
                    'content' => $section['content'] ?? null,
                    'background_color' => $section['background_color'] ?? null,
                    'image_path' => $imagePath,
                    'image_position' => $section['position'] ?? null,
                    'image_description' => $section['image_description'] ?? null,
                    // 'order_no' => $order,
                ]);
            }

            return redirect()->route('admin.cms.contents')->with('success','Page Content Set Successfully');

        } catch (\Exception $e) {
            Log::error('Page Content Create Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function contentUpdate(Request $request, $contentId)
    {
        try {
            $auth = Auth::user();
            $contentId = safe_decrypt($contentId);
            $data = [];

            $section = PageContent::findOrFail($contentId);

            if ($request->has('title')) {
                $data['title'] = $request->input('title');
            }

            if ($request->has('content')) {
                $data['content'] = $request->input('content');
            }

            if ($request->has('background_color')) {
                $data['background_color'] = $request->input('background_color');
            }

            if ($request->has('image_description')) {
                $data['image_description'] = $request->input('image_description');
            }

            if ($request->has('position')) {
                $data['image_position'] = $request->input('position');
            }

            // Handle optional image/video upload
            if (!empty($request->file('image'))) {
                $imagePath = $request->file('image')->store('uploads/content', 'public');
                $data['image_path'] = $imagePath;
            }

            // Update the section with only available data
            $section->update($data);

            return redirect()->route('admin.cms.content.manage', ['menuId' => safe_encrypt($section->menu_id)])->with('success', 'Section updated successfully.');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Section Content Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function checkContent($menuId)
    {
        $hasContent = PageContent::where('menu_id', $menuId)->exists();

        if ($hasContent) {
            return response()->json([
                'exists' => true,
                'encrypted_id' => safe_encrypt($menuId),
            ]);
        }

        return response()->json(['exists' => false]);
    }

    public function manageContent($menuId)
    {
        $auth = Auth::user();
        $menuId = safe_decrypt($menuId);
        $content = PageContent::where('menu_id', $menuId)
                    ->orderBy('order_no')
                    ->get();

        $menu = Menu::where('id', $menuId)->where('institute_id', $auth->active_institute)->with('parent')->first();

        return view('admin.cms.manage_content', compact('content', 'menu'));
    }

    public function editContent(Request $request, $contentId)
    {        
        try {
            $auth = Auth::user();
            $contentId = safe_decrypt($contentId);

            $section = PageContent::findOrFail($contentId);

            $menu = Menu::where('id', $section->menu_id)->where('institute_id', $auth->active_institute)->with('parent')->first();

            return view('admin.cms.edit_content', compact('section', 'menu'));

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Edit Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    public function updateOrder(Request $request)
    {
        foreach ($request->order as $item) {
            PageContent::where('id', $item['id'])->update(['order_no' => $item['order_no']]);
        }

        return response()->json(['success' => true]);
    }

    public function destroySection(Request $request)
    {
        try {
            $data = PageContent::findOrFail($request->id);

            $data->delete();

            activityLog('Module-Section', 'Module Section Deleted successfully');

            return redirect()->back()->with('success','Section Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Section Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Section Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
