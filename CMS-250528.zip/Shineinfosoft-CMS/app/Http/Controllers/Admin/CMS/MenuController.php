<?php

namespace App\Http\Controllers\Admin\CMS;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MenuController extends Controller
{
    public function storeOrUpdate(Request $request)
    {
        $data = $request->validate([
            'id' => 'nullable|exists:menus,id',
            'institute_id' => 'required|exists:institutes,id',
            'parent_id' => 'nullable|exists:menus,id',
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:menus,slug,' . $request->id,
            'url' => 'nullable|string|max:255',
            'order_no' => 'nullable|integer',
            'is_active' => 'nullable|boolean',
        ]);

        $menu = Menu::updateOrCreate(['id' => $data['id'] ?? null], $data);

        return response()->json([
            'status' => 'success',
            'menu' => $menu
        ]);
    }

    public function listByInstitute($id)
    {
        $menus = Menu::where('institute_id', $id)
                    ->whereNull('parent_id')
                    ->with('children')
                    ->orderBy('order_no')
                    ->get();

        return response()->json($menus);
    }

    public function modulesView()
    {
        $auth = Auth::user();
        
        $menus = Menu::where('institute_id', $auth->active_institute)
                    ->whereNull('parent_id')
                    ->with('children')
                    ->orderBy('order_no')
                    ->get();

        // $menus = Menu::where('institute_id', $instituteId)
        //     ->whereNull('parent_id')
        //     ->where('show_on_website', true)
        //     ->with(['children' => function ($q) {
        //         $q->where('show_on_website', true);
        //     }])
        //     ->orderBy('order_no')
        //     ->get();

        return view('admin.cms.modules', compact('menus'));
    }

    public function updateMenuVisibility(Request $request)
    {
        $auth = Auth::user();
        $instituteId = $auth->active_institute;

        // Get all menu IDs of the institute
        $menuIds = Menu::where('institute_id', $instituteId)->pluck('id');

        foreach ($menuIds as $id) {
            $show = $request->input("menu_visibility.$id", false);
            Menu::where('id', $id)->update(['show_on_website' => $show]);
        }

        return redirect()->back()->with('success', 'Menu visibility updated successfully.');
    }

    public function getSubmenus($parentId)
    {
        $menus = Menu::where('parent_id', $parentId)
                    ->where('show_on_website', true)
                    ->orderBy('order_no')
                    ->get();

        return response()->json($menus);
    }
}
