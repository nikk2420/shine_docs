<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Role;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;

class RoleManagementController extends Controller
{
    public function index()
    {
        return view('admin.role_management.index');
    }

    public function getRoleList()
    {
        // $roles = Role::with('permissions')->get();
        $roles = Role::get();

        return DataTables::of($roles)
            ->editColumn('is_active', function ($row) {
                if($row->is_active === 1){
                    return '<span class="badge badge-success">Active</span>';
                }else{
                    return '<span class="badge badge-danger">Inactive</span>';
                }                
            })
            ->addColumn('action', function ($row) {
                $html = '';
                if((Auth::user()->role_id === $row->id) || ($row->id == 1)){
                    $html .= '-';
                }else{
                    if(can_access('Roles', 'update')){
                        $encryptedId = safe_encrypt($row->id);
                        $html .= '<a href="' . route('admin.role.edit', ['id' => $encryptedId]) . '" class="btn btn-sm btn-primary">Edit</a> ';
                    }
                    
                    if(can_access('Roles', 'delete')){
                        $html .='<button type="button" class="btn btn-danger btn-sm ms-2" 
                                        data-id="' . $row->id . '" 
                                        data-toggle="modal" 
                                        data-target="#deleteRoleModal">
                                    Delete
                                </button>';
                    }
                    
                }       
                return $html;         
            })
            ->rawColumns(['is_active','action'])
            ->make(true);
    }

    public function addRole()
    {
        // $modules = config('modules.modules');
        return view('admin.role_management.create');
    }

    public function create(Request $request)
    {
        // Validate input
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:roles,name',
            'description' => 'nullable|string',
            'permissions' => 'nullable|array',
            'permissions.*.module' => 'required|string',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $role = Role::create([
            'name' => $request->name,
            'description' => $request->description,
            'is_active' => $request->is_active ?? false,
        ]);

        foreach ($request->permissions as $perm) {
            $role->permissions()->create($perm);
        }

        activityLog('Role-Management', 'Role created successfully');

        return redirect()->route('admin.role')->with('success', 'Role created successfully.');
    }

    public function editRole($encryptedId)
    {
        try {
            $id = safe_decrypt($encryptedId);

            $role = Role::with('permissions')->findOrFail($id);

            return view('admin.role_management.create', [
                'role' => $role,
                'formAction' => route('admin.role.update', $encryptedId),
                'isEdit' => true
            ]);

       } catch (ModelNotFoundException $e) {
           return redirect()->back()->withErrors(['error' => 'Role Not Found!']);
       } catch (\Exception $e) {
           Log::error('Edit Role Error:', ['exception' => $e->getMessage()]);
           return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
       }
    }

    public function update(Request $request, $encryptedId)
    {
        try {
            $id = safe_decrypt($encryptedId);
            $auth_user = Auth::user();

            if($auth_user->role_id === $id){
                activityLog('Role-Management','You can not update your own role!');
                return redirect()->back()
                    ->withErrors(['warning' => 'You can not update your own role!'])
                    ->withInput();
            }

            $role = Role::findOrFail($id);

            // Validate input
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|unique:roles,name,' . $role->id,
                'description' => 'nullable|string',
                'permissions' => 'nullable|array',
                'permissions.*.module' => 'required|string',
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            // Update role data
            $role->update([
                'name' => $request->name,
                'description' => $request->description,
                'is_active' => $request->has('is_active') ? 1 : 0,
            ]);

            // Replace permissions
            $role->permissions()->delete();

            foreach ($request->permissions as $perm) {
                $role->permissions()->create([
                    'module' => $perm['module'],
                    'can_view' => isset($perm['can_view']),
                    'can_add' => isset($perm['can_add']),
                    'can_update' => isset($perm['can_update']),
                    'can_delete' => isset($perm['can_delete']),
                ]);
            }

            activityLog('Role-Management', 'Role Updated successfully');

            return redirect()->route('admin.role')->with('success', 'Role updated successfully.');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Role not found.']);
        } catch (\Exception $e) {
            Log::error('Role Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again.']);
        }
    }

    public function destroy(Request $request)
    {
        try {
             // $id = safe_decrypt($encryptedId);
            $role = Role::findOrFail($request->id);

            $role->permissions()->delete();

            $role->delete();

            activityLog('Role-Management', 'Role Deleted successfully');

            return redirect()->route('admin.role')->with('success','Role Delete Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Activity Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Activity Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
