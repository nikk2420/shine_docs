<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Institute;
use App\Models\Role;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;

class AdminManagementController extends Controller
{
    public function index()
    {
        return view('admin.admin_management.index');
    }

    public function getUserList()
    {
        $users = User::orderBy('id','desc')->get();

        return DataTables::of($users)
            ->addColumn('action', function ($row) {
                $html = '';

                if(Auth::user()->id === $row->id){
                    $html .= '-';
                }else{
                    $encryptedId = safe_encrypt($row->id);
                    if(can_access('Admins', 'view')){
                        $html .= '<a href="' . route('admin.user.view', ['id' => $encryptedId]) . '" class="btn btn-sm btn-secondary">View</a> ';
                    }

                    if(can_access('Admins', 'update')){
                        $html .= '<a href="' . route('admin.user.edit', ['id' => $encryptedId]) . '" class="btn btn-sm btn-primary">Edit</a> ';
                    }
                    
                    if(can_access('Admins', 'delete')){
                        $html .='<button type="button" class="btn btn-danger btn-sm ms-2" 
                                            data-id="' . $row->id . '" 
                                            data-toggle="modal" 
                                            data-target="#deleteAdminModal">
                                        Delete
                                    </button>';
                    }                    
                }
                
                return $html;  
            })
            ->rawColumns(['action']) // render HTML
            ->make(true);
    }

    public function addAdmin()
    {
        $roles = Role::get();
        $institutes = Institute::all();
        return view('admin.admin_management.create',compact('roles','institutes'));
    }

    public function create(Request $request)
    {
        // Validate input
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email',
            'role' => 'required|exists:roles,id',
            'institute' => 'nullable|array',
            'institute.*' => 'exists:institutes,id',
            'password' => [
                    'required',
                    'string',
                    'min:8',
                    'max:16',
                    'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,16}$/',
                ],
        ], [
            'role.required' => 'Role is required.',
            'role.exists' => 'Selected role is invalid.',
            'password.regex' => 'Password must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.',
            'password.confirmed' => 'Password confirmation does not match.',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'role_id' => $request->role,
            'email_verified_at' => Carbon::now(),
            'password' => Hash::make($request->password),
        ]);

        // Sync multiple institutes if selected
        if ($request->has('institute') && is_array($request->institute)) {
            $user->assignedInstitutes()->sync($request->institute);
        }

        activityLog('Admin-Management', 'Admin created successfully');

        return redirect()->route('admin.management')->with('success', 'Admin created successfully.');
    }

    public function editAdmin($encryptedId)
    {
        try {
            $id = safe_decrypt($encryptedId);

            $user = User::findOrFail($id);
            $roles = Role::get();
            $institutes = Institute::all();

            return view('admin.admin_management.create', [
                'user' => $user,
                'roles' => $roles,
                'institutes' => $institutes,
                'formAction' => route('admin.user.update', $encryptedId),
                'isEdit' => true
            ]);

       } catch (ModelNotFoundException $e) {
           return redirect()->back()->withErrors(['error' => 'Admin Not Found!']);
       } catch (\Exception $e) {
           Log::error('Edit Admin Error:', ['exception' => $e->getMessage()]);
           return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
       }
    }

    public function update(Request $request, $encryptedId)
    {
        try{
            $id = safe_decrypt($encryptedId);
            $user = User::findOrFail($id);

             // Validate input
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => [
                    'required',
                    'email',
                    'max:255',
                    Rule::unique('users', 'email')->ignore($user->id)
                ],
                'role' => 'required|exists:roles,id',
                'institute' => 'nullable|array',
                'institute.*' => 'exists:institutes,id',
                'password' => [
                        'nullable',
                        'string',
                        'min:8',
                        'max:16',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,16}$/',
                    ],
            ], [
                'role.required' => 'Role is required.',
                'role.exists' => 'Selected role is invalid.',
                'password.regex' => 'Password must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.',
                'password.confirmed' => 'Password confirmation does not match.',
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            $user->update([
                'name' => $request->name,
                'email' => $request->email,
                'role_id' => $request->role,
                'password' => $request->filled('password') ? Hash::make($request->password) : $user->password,
            ]);

            // Sync assigned institutes (null means no restriction)
            $user->assignedInstitutes()->sync($request->input('institute', []));

            activityLog('Admin-Management', 'Admin Updated successfully');

            return redirect()->route('admin.management')->with('success', 'Admin Updated successfully.');
            
        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Admin not found.']);
        } catch (\Exception $e) {
            Log::error('Admin Update Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again.']);
        }
    }

    public function viewAdmin($encryptedId)
    {
        try {
            $id = safe_decrypt($encryptedId);

            $user = User::findOrFail($id);
            $roles = Role::get();

            return view('admin.admin_management.view', [
                'user' => $user,
                'roles' => $roles,
            ]);

       } catch (ModelNotFoundException $e) {
           return redirect()->back()->withErrors(['error' => 'Admin Not Found!']);
       } catch (\Exception $e) {
           Log::error('Edit Admin Error:', ['exception' => $e->getMessage()]);
           return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
       }
    }

    public function destroy(Request $request)
    {
        try {
            $user = User::findOrFail($request->id);

            $user->delete();

            activityLog('Admin-Management', 'Admin User Deleted successfully');

            return redirect()->route('admin.management')->with('success','Admin User Deleted Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Admin Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Admin Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
