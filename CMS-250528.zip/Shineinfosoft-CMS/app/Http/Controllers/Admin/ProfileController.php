<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        return view('admin.profile.index', compact('user'));

    }

    public function update(Request $request)
    {
        try {
            $user = Auth::user();
            
            $updateData = [];

            if ($request->filled('name')) {
                $updateData['name'] = $request->name;
            }

            $user->update($updateData);

            activityLog('User-Profile','Profile Updated Successfully.',$request->email);

            return redirect()->route('admin.profile')->with('success','Profile Updated Successfully');

        } catch (\Exception $e) {
            Log::error('Update Profile Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }

    // public function userUpdate(Request $request)
    // {
    //     try {
    //         $auth_user = Auth::user();
            
    //         $user = User::findOrFail($request->id);

    //         $updateData = [];

    //         if ($request->filled('name')) {
    //             $updateData['name'] = $request->name;
    //         }

    //         $user->update($updateData);

    //         activityLog('User-Profile','Profile Updated Successfully.',$request->email);

    //         return redirect()->route('admin.profile')->with('success','Profile Updated Successfully');

    //     } catch (ModelNotFoundException $e) {
    //         return redirect()->back()->withErrors(['error' => 'User Not Found!']);
    //     } catch (\Exception $e) {
    //         Log::error('Update Profile Error:', ['exception' => $e->getMessage()]);
    //         return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
    //     }
    // }

    public function changePassword()
    {
        $user = Auth::user();

        return view('admin.profile.change_password', compact('user'));
    }

    public function editPassword(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'old_password' => 'required',
                'new_password' => [
                        'required',
                        'string',
                        'min:8',
                        'max:16',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,16}$/',
                        'confirmed'
                    ],
            ],[
                'new_password.regex' => 'Password must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.',
                'new_password.confirmed' => 'The password confirmation does not match.',
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            $user = Auth::user();

            if (!Hash::check($request->old_password, $user->password)) {
                return back()->withErrors(['old_password' => 'Old password is incorrect']);
            }

            $user->update([
                'password' => Hash::make($request->new_password),
            ]);

            activityLog('Change-Password', 'Password changed successfully', $user->email);

            return redirect()->route('admin.dashboard')->with('success', 'Password changed successfully!');

        } catch (\Exception $e) {
            Log::error('Change Password Error:', ['exception' => $e->getMessage()]);
            return back()->withErrors(['error' => 'Something went wrong. Please try again later.']);
        }
    }

}
