<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Yajra\DataTables\Facades\DataTables;

class ActivityLogController extends Controller
{
    public function index()
    {
        return view('admin.activity_log.index');
    }

    public function getActivityList()
    {
        $logs = ActivityLog::orderBy('id','desc')->get();

        return DataTables::of($logs)
        ->addColumn('user', function ($row) {
            return $row->user?->name ?? 'System';
        })
        ->editColumn('created_at', function ($row) {
            return $row->created_at->format('Y-m-d H:i:s');
        })
        ->addColumn('action_list', function ($row) {
            // $encryptedId = safe_encrypt($row->id);
            // return '
            //     <form action="' . route('admin.activity.destroy') . '" method="POST" style="display:inline;">
            //         <input type="hidden" name="_token" value="' . csrf_token() . '">
            //         <input type="hidden" name="_method" value="DELETE">
            //         <input type="hidden" name="id" value="'. $row->id .'">
            //         <button type="submit" class="btn btn-danger btn-sm ms-2" onclick="return confirm(\'Are you sure?\')">Delete</button>
            //     </form>';
            $html = '';
            if(can_access('Activity', 'delete')){
                $html .= '
                <button type="button" class="btn btn-danger btn-sm ms-2" 
                        data-id="' . $row->id . '" 
                        data-toggle="modal" 
                        data-target="#deleteActivityModal">
                    Delete
                </button>';
            }else{
                $html .= '-';
            }

            return $html;
        })
        ->rawColumns(['action_list'])
        ->make(true);
    }

    public function destroy(Request $request)
    {
        try {
             // $id = safe_decrypt($encryptedId);
            $activity = ActivityLog::findOrFail($request->id);

            $activity->delete();

            return redirect()->route('admin.activity')->with('success','Activity Delete Successfully');

        } catch (ModelNotFoundException $e) {
            return redirect()->back()->withErrors(['error' => 'Activity Not Found!']);
        } catch (\Exception $e) {
            Log::error('Delete Activity Error:', ['exception' => $e->getMessage()]);
            return redirect()->back()->withErrors(['error' => 'Something went wrong. Please try again!']);
        }
    }
}
