<?php return array('dependencies' => array(), 'version' => '0af1adf2b74c452622ed');
